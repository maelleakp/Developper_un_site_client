﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NEGOSUD.DataAccess.Migrations
{
    /// <inheritdoc />
    public partial class commandeupdate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_OrdersC_Customers_CustomerId",
                table: "OrdersC");

            migrationBuilder.DropForeignKey(
                name: "FK_OrdersC_Status_StatusId",
                table: "OrdersC");

            migrationBuilder.DropIndex(
                name: "IX_OrdersC_CustomerId",
                table: "OrdersC");

            migrationBuilder.DropIndex(
                name: "IX_OrdersC_StatusId",
                table: "OrdersC");

            migrationBuilder.DropColumn(
                name: "CustomerId",
                table: "OrdersC");

            migrationBuilder.DropColumn(
                name: "StatusId",
                table: "OrdersC");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "CustomerId",
                table: "OrdersC",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "StatusId",
                table: "OrdersC",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_OrdersC_CustomerId",
                table: "OrdersC",
                column: "CustomerId");

            migrationBuilder.CreateIndex(
                name: "IX_OrdersC_StatusId",
                table: "OrdersC",
                column: "StatusId");

            migrationBuilder.AddForeignKey(
                name: "FK_OrdersC_Customers_CustomerId",
                table: "OrdersC",
                column: "CustomerId",
                principalTable: "Customers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_OrdersC_Status_StatusId",
                table: "OrdersC",
                column: "StatusId",
                principalTable: "Status",
                principalColumn: "Id");
        }
    }
}
