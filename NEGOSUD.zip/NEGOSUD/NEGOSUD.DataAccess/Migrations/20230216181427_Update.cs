﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NEGOSUD.DataAccess.Migrations
{
    /// <inheritdoc />
    public partial class Update : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_providers_Name",
                table: "providers");

            migrationBuilder.DropIndex(
                name: "IX_providers_Phone",
                table: "providers");

            migrationBuilder.DropIndex(
                name: "IX_providers_Siret",
                table: "providers");

            migrationBuilder.DropIndex(
                name: "IX_providers_WebSite",
                table: "providers");

            migrationBuilder.DropColumn(
                name: "LastName",
                table: "providers");

            migrationBuilder.DropColumn(
                name: "Name",
                table: "providers");

            migrationBuilder.DropColumn(
                name: "Siret",
                table: "providers");

            migrationBuilder.DropColumn(
                name: "WebSite",
                table: "providers");

            migrationBuilder.AlterColumn<string>(
                name: "Phone",
                table: "providers",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AddColumn<int>(
                name: "ProviderId",
                table: "Items",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ProviderId",
                table: "Items");

            migrationBuilder.AlterColumn<string>(
                name: "Phone",
                table: "providers",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<string>(
                name: "LastName",
                table: "providers",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Name",
                table: "providers",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Siret",
                table: "providers",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "WebSite",
                table: "providers",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_providers_Name",
                table: "providers",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_providers_Phone",
                table: "providers",
                column: "Phone",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_providers_Siret",
                table: "providers",
                column: "Siret",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_providers_WebSite",
                table: "providers",
                column: "WebSite",
                unique: true);
        }
    }
}
