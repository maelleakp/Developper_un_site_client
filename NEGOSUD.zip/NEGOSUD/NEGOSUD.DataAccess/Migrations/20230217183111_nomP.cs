﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NEGOSUD.DataAccess.Migrations
{
    /// <inheritdoc />
    public partial class nomP : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ProviderId",
                table: "Items");

            migrationBuilder.AddColumn<string>(
                name: "ProviderName",
                table: "Items",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ProviderName",
                table: "Items");

            migrationBuilder.AddColumn<int>(
                name: "ProviderId",
                table: "Items",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
