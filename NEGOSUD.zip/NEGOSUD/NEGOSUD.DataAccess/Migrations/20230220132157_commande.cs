﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NEGOSUD.DataAccess.Migrations
{
    /// <inheritdoc />
    public partial class commande : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_OrdersC_Status_StatusId",
                table: "OrdersC");

            migrationBuilder.DropColumn(
                name: "DeliveryDate",
                table: "OrdersC");

            migrationBuilder.DropColumn(
                name: "OrderDate",
                table: "OrdersC");

            migrationBuilder.RenameColumn(
                name: "OrderNumber",
                table: "OrdersC",
                newName: "Reference");

            migrationBuilder.RenameIndex(
                name: "IX_OrdersC_OrderNumber",
                table: "OrdersC",
                newName: "IX_OrdersC_Reference");

            migrationBuilder.AlterColumn<int>(
                name: "StatusId",
                table: "OrdersC",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddForeignKey(
                name: "FK_OrdersC_Status_StatusId",
                table: "OrdersC",
                column: "StatusId",
                principalTable: "Status",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_OrdersC_Status_StatusId",
                table: "OrdersC");

            migrationBuilder.RenameColumn(
                name: "Reference",
                table: "OrdersC",
                newName: "OrderNumber");

            migrationBuilder.RenameIndex(
                name: "IX_OrdersC_Reference",
                table: "OrdersC",
                newName: "IX_OrdersC_OrderNumber");

            migrationBuilder.AlterColumn<int>(
                name: "StatusId",
                table: "OrdersC",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "DeliveryDate",
                table: "OrdersC",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "OrderDate",
                table: "OrdersC",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddForeignKey(
                name: "FK_OrdersC_Status_StatusId",
                table: "OrdersC",
                column: "StatusId",
                principalTable: "Status",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
