﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NEGOSUD.DataAccess.Migrations
{
    /// <inheritdoc />
    public partial class nomWT : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_WineTypes",
                table: "WineTypes");

            migrationBuilder.DropColumn(
                name: "WineTypeId",
                table: "Items");

            migrationBuilder.AddColumn<string>(
                name: "WineTypeName",
                table: "Items",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddPrimaryKey(
                name: "PK_WineTypes",
                table: "WineTypes",
                column: "Name");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_WineTypes",
                table: "WineTypes");

            migrationBuilder.DropColumn(
                name: "WineTypeName",
                table: "Items");

            migrationBuilder.AddColumn<int>(
                name: "WineTypeId",
                table: "Items",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddPrimaryKey(
                name: "PK_WineTypes",
                table: "WineTypes",
                column: "Id");
        }
    }
}
