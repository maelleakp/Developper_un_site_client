﻿using System;
using System.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NEGOSUD.Common.Models;

namespace NEGOSUD.DataAccess.EntityConfiguration
{
	public class WineTypeEntityConfiguration : IEntityTypeConfiguration<WineType>
    {
		public WineTypeEntityConfiguration()
		{
		}

        public void Configure(EntityTypeBuilder<WineType> winetype)
        {
            winetype.HasKey(wt => wt.Name);
            winetype.Property(wt => wt.Id).ValueGeneratedOnAdd();

            winetype.Property<string>("Name").IsRequired();

            winetype.HasIndex(wt => wt.Name).IsUnique();

        }
    }
}

