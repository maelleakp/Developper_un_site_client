﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NEGOSUD.Common.Models;

namespace NEGOSUD.DataAccess.EntityConfiguration
{
	public class ItemEntityConfiguration : IEntityTypeConfiguration<Item>
    {
		public ItemEntityConfiguration()
		{
		}

        public void Configure(EntityTypeBuilder<Item> item)
        {
            item.HasKey(i => i.Id);
            item.Property(i => i.Id).ValueGeneratedOnAdd();

            item.Property<string>("Name").IsRequired();
            item.Property<string>("Appellation").IsRequired();
            item.Property<float>("Volume").IsRequired();
            item.Property<int>("Year").IsRequired();
            item.Property<float>("UnitPrice").IsRequired();
            item.Property<float>("BoxPrice").IsRequired();
            item.Property<string>("Region").IsRequired();

        }
    }
}

