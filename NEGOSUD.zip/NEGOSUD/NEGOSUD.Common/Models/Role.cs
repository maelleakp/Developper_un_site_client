﻿using System;
using NEGOSUD.Common.Core;

namespace NEGOSUD.Common.Models
{
	public class Role : Entity
	{
		public string Name { get; set; } = string.Empty;

		public Role()
		{
		}
	}
}

