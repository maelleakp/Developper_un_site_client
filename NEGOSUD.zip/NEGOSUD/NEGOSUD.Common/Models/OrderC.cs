﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using NEGOSUD.Common.Core;

namespace NEGOSUD.Common.Models
{
	public class OrderC : Entity
	{
		public string Reference { get; set; } = string.Empty;

		public int Quantity { get; set; } = int.MinValue;

		public float Price { get; set; } = float.MinValue;

        public OrderC()
		{
        }
	}
}

