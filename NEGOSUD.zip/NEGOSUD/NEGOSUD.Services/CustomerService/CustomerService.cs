﻿using System;
using Microsoft.EntityFrameworkCore;
using NEGOSUD.Common.Models;
using NEGOSUD.DataAccess;

namespace NEGOSUD.Services.CustomerService
{
	public class CustomerService : ICustomerService
	{
        private readonly DataContext _context;

        public CustomerService(DataContext context)
		{
            _context = context;
        }

        public async Task<List<Customer>> AddCustomer(Customer customer)
        {
            _context.Customers.Add(customer);
            await _context.SaveChangesAsync();

            return await _context.Customers.ToListAsync();
        }

        public async Task<List<Customer>?> DeleteCustomer(int id)
        {
            var customer = await _context.Customers.FindAsync(id);
            if (customer is null)
                return null;

            _context.Customers.Remove(customer);
            await _context.SaveChangesAsync();

            return await _context.Customers.ToListAsync();
        }

        public async Task<List<Customer>> GetAllCustomers()
        {
            var customers = await _context.Customers.ToListAsync();
            return customers;
        }

        public async Task<Customer?> GetOneCustomer(int id)
        {
            var customer = await _context.Customers.FindAsync(id);
            if (customer is null)
                return null;

            return customer;
        }

        public async Task<List<Customer>?> UpdateCustomer(Customer request)
        {
            var customer = await _context.Customers.FindAsync(request.Id);
            if (customer is null)
                return null;


            if (request.Name != string.Empty)
                customer.Name = request.Name;

            if (request.LastName != string.Empty )
                customer.LastName = request.LastName;

            if (request.Phone != string.Empty)
                customer.Phone = request.Phone;

            if (request.Email != string.Empty)
                customer.Email = request.Email;

            if (request.Birthday != DateTime.MinValue)
                customer.Birthday = request.Birthday;

            if (request.PostalCode != string.Empty)
                customer.PostalCode = request.PostalCode;

            if (request.City != string.Empty)
                customer.City = request.City;

            if (request.Street != string.Empty)
                customer.Street = request.Street;

            await _context.SaveChangesAsync();

            return await _context.Customers.ToListAsync();
        }
    }
}

