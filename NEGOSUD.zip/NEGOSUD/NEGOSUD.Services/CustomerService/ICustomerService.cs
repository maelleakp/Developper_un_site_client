﻿using System;
using NEGOSUD.Common.Models;

namespace NEGOSUD.Services.CustomerService
{
	public interface ICustomerService
	{
        Task<List<Customer>> GetAllCustomers();

        Task<Customer?> GetOneCustomer(int id);

        Task<List<Customer>> AddCustomer(Customer customer);

        Task<List<Customer>?> UpdateCustomer(Customer request);

        Task<List<Customer>?> DeleteCustomer(int id);
    }
}

