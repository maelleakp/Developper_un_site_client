﻿using System;
using Microsoft.EntityFrameworkCore;
using NEGOSUD.Common.Models;
using NEGOSUD.DataAccess;

namespace NEGOSUD.Services.OrderPService
{
	public class OrderPService : IOrderPService
	{
        private readonly DataContext _context;

        public OrderPService(DataContext context)
		{
            _context = context;
        }

        public async Task<List<OrderP>> AddOrderP(OrderP orderP)
        {
            _context.OrdersP.Add(orderP);
            await _context.SaveChangesAsync();

            return await _context.OrdersP.ToListAsync();
        }

        public async Task<List<OrderP>?> DeleteOrderP(int id)
        {
            var orderP = await _context.OrdersP.FindAsync(id);
            if (orderP is null)
                return null;

            _context.OrdersP.Remove(orderP);
            await _context.SaveChangesAsync();

            return await _context.OrdersP.ToListAsync();
        }

        public async Task<List<OrderP>> GetAllOrdersP()
        {
            var ordersP = await _context.OrdersP.ToListAsync();
            return ordersP;
        }

        public async Task<OrderP?> GetOneOrderP(int id)
        {
            var orderP = await _context.OrdersP.FindAsync(id);
            if (orderP is null)
                return null;

            return orderP;
        }

        public async Task<List<OrderP>?> UpdateOrderP(OrderP request)
        {
            var orderP = await _context.OrdersP.FindAsync(request.Id);
            if (orderP is null)
                return null;

            if (request.OrderNumber != string.Empty)
                orderP.OrderNumber = request.OrderNumber;

            if (request.OrderDate != DateTime.MinValue)
                orderP.OrderDate = request.OrderDate;

            if (request.Quantity != int.MinValue)
                orderP.Quantity = request.Quantity;

            if (request.Price != int.MinValue)
                orderP.Price = request.Price;

            await _context.SaveChangesAsync();

            return await _context.OrdersP.ToListAsync();
        }
    }
}

