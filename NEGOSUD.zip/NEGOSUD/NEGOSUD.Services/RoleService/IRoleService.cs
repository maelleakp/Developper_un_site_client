﻿using System;
using NEGOSUD.Common.Models;

namespace NEGOSUD.Services.RoleService
{
	public interface IRoleService
	{
        Task<List<Role>> GetAllRoles();

        Task<Role?> GetOneRole(int id);

        Task<List<Role>> AddRole(Role role);

        Task<List<Role>?> UpdateRole(Role request);

        Task<List<Role>?> DeleteRole(int id);
    }
}

