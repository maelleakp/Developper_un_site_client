﻿using System;
using NEGOSUD.Common.Models;

namespace NEGOSUD.Services.EmployeeService
{
	public interface IEmployeeService
	{
        Task<List<Employee>> GetAllEmployees();

        Task<Employee?> GetOneEmployee(int id);

        Task<List<Employee>> AddEmployee(Employee employee);

        Task<List<Employee>?> UpdateEmployee(Employee request);

        Task<List<Employee>?> DeleteEmployee(int id);

    }
}

