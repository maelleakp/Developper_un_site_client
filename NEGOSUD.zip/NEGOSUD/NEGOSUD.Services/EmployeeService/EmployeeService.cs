﻿using System;
using Microsoft.EntityFrameworkCore;
using NEGOSUD.Common.Models;
using NEGOSUD.DataAccess;

namespace NEGOSUD.Services.EmployeeService
{
	public class EmployeeService : IEmployeeService
    {
        private readonly DataContext _context;

        public EmployeeService(DataContext context)
        {
            _context = context;
        }

        public async Task<List<Employee>> AddEmployee(Employee employee)
        {
            _context.Employees.Add(employee);
            await _context.SaveChangesAsync();

            return await _context.Employees.ToListAsync();
        }

        public async Task<List<Employee>?> DeleteEmployee(int id)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee is null)
                return null;

            _context.Employees.Remove(employee);
            await _context.SaveChangesAsync();

            return await _context.Employees.ToListAsync();
        }

        public async Task<List<Employee>> GetAllEmployees()
        {
            var employees = await _context.Employees.ToListAsync();
            return employees;
        }

        public async Task<Employee?> GetOneEmployee(int id)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee is null)
                return null;

            return employee;
        }

        public async Task<List<Employee>?> UpdateEmployee(Employee request)
        {
            var employee = await _context.Employees.FindAsync(request.Id);
            if (employee is null)
                return null;


            if (request.Name != string.Empty)
                employee.Name = request.Name;

            if (request.LastName != string.Empty)
                employee.LastName = request.LastName;

            if (request.Email != string.Empty)
                employee.Email = request.Email;

            if (request.Password != string.Empty)
                employee.Password = request.Password;

            await _context.SaveChangesAsync();

            return await _context.Employees.ToListAsync();
        }

    }
}

